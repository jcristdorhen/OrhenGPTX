"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { useChatStore } from "@/lib/store"

export default function Footer() {
  const { isChatMode } = useChatStore()

  return (
    <motion.footer
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="p-4 text-center text-sm text-gray-600"
    >
      {isChatMode ? (
        <p>ChatGPT can make mistakes. Check important info.</p>
      ) : (
        <p>
          By messaging ChatGPT, you agree to our{" "}
          <Link href="#" className="text-gray-800 font-medium">
            Terms
          </Link>{" "}
          and have read our{" "}
          <Link href="#" className="text-gray-800 font-medium">
            Privacy Policy
          </Link>
          .
        </p>
      )}
    </motion.footer>
  )
}

