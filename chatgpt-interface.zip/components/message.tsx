"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import type { Message as MessageType } from "@/lib/store"
import { ClipboardIcon, CheckIcon } from "lucide-react"
import MarkdownRenderer from "./markdown-renderer"

interface MessageProps {
  message: MessageType
}

export default function Message({ message }: MessageProps) {
  const [copied, setCopied] = useState(false)

  const copyToClipboard = () => {
    navigator.clipboard.writeText(message.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`py-5 ${message.role === "assistant" ? "bg-white" : "bg-gray-50"}`}
    >
      <div className="max-w-3xl mx-auto px-4">
        <div className="flex">
          <div className="flex-grow">
            {message.role === "user" ? (
              <p className="text-gray-800">{message.content}</p>
            ) : (
              <MarkdownRenderer content={message.content} />
            )}

            {message.attachments && message.attachments.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {message.attachments.map((attachment, index) => (
                  <div key={index} className="border rounded-md p-2 bg-gray-50">
                    <p className="text-sm font-medium">{attachment.name}</p>
                    {attachment.type.startsWith("image/") ? (
                      <img
                        src={attachment.url || "/placeholder.svg"}
                        alt={attachment.name}
                        className="mt-1 max-w-xs max-h-40 object-contain"
                      />
                    ) : (
                      <p className="text-xs text-gray-500">{attachment.type}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {message.role === "assistant" && (
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={copyToClipboard}
              className="ml-2 p-1 text-gray-400 hover:text-gray-600"
              aria-label="Copy to clipboard"
            >
              {copied ? <CheckIcon size={16} /> : <ClipboardIcon size={16} />}
            </motion.button>
          )}
        </div>
      </div>
    </motion.div>
  )
}

