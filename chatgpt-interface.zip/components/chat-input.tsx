"use client"

import type React from "react"

import { useState, type FormEvent, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { PaperclipIcon, SearchIcon, LightbulbIcon, MicIcon, XIcon } from "lucide-react"
import TextareaAutosize from "react-textarea-autosize"
import { useChatStore } from "@/lib/store"
import { sendMessage, searchQuery } from "@/lib/chat-service"

export default function ChatInput() {
  const [input, setInput] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [attachments, setAttachments] = useState<Array<{ file: File; url: string }>>([])
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const { addMessage, messages, setLoading, isLoading, setChatMode, inputMode, setInputMode, setSearchResults } =
    useChatStore()

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()

    if ((!input.trim() && attachments.length === 0) || isLoading) return

    // Set chat mode if this is the first message
    if (messages.length === 0) {
      setChatMode(true)
    }

    // Process based on input mode
    if (inputMode === "search") {
      // Handle search
      try {
        const results = await searchQuery(input)
        setSearchResults(results)

        // Add user message with search query
        addMessage({
          role: "user",
          content: `Search: ${input}`,
        })

        // Send to chat API with search mode
        await handleChatResponse(input, "search")
      } catch (error) {
        console.error("Search error:", error)
      }
    } else {
      // Regular message or with attachments
      const messageAttachments = attachments.map((att) => ({
        type: att.file.type,
        url: att.url,
        name: att.file.name,
      }))

      // Add user message
      addMessage({
        role: "user",
        content: input,
        attachments: messageAttachments.length > 0 ? messageAttachments : undefined,
      })

      // Send to chat API
      await handleChatResponse(input)
    }

    // Reset state
    setInput("")
    setAttachments([])
    setInputMode("normal")
  }

  const handleChatResponse = async (userInput: string, mode = "normal") => {
    setLoading(true)

    try {
      // Get all messages including the new one
      const allMessages = [
        ...messages,
        { id: "temp", role: "user" as const, content: userInput, timestamp: Date.now() },
      ]

      // Send to API
      const response = await sendMessage(allMessages, mode)

      // Add assistant response
      addMessage({ role: "assistant", content: response })
    } catch (error) {
      console.error("Error in chat:", error)
      addMessage({
        role: "assistant",
        content: "Sorry, I encountered an error processing your request.",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleAttachClick = () => {
    if (inputMode === "attach") {
      setInputMode("normal")
    } else {
      setInputMode("attach")
      if (fileInputRef.current) {
        fileInputRef.current.click()
      }
    }
  }

  const handleSearchClick = () => {
    setInputMode(inputMode === "search" ? "normal" : "search")
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }

  const handleVoiceClick = () => {
    if (inputMode === "voice") {
      setInputMode("normal")
      setIsRecording(false)
    } else {
      setInputMode("voice")
      setIsRecording(true)
      // In a real implementation, this would start recording
      setTimeout(() => {
        setInput((prev) => prev + " (Voice transcription would appear here)")
        setIsRecording(false)
        setInputMode("normal")
      }, 3000)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    const newAttachments = Array.from(files).map((file) => ({
      file,
      url: URL.createObjectURL(file),
    }))

    setAttachments((prev) => [...prev, ...newAttachments])
  }

  const removeAttachment = (index: number) => {
    setAttachments((prev) => {
      const newAttachments = [...prev]
      URL.revokeObjectURL(newAttachments[index].url)
      newAttachments.splice(index, 1)
      return newAttachments
    })
  }

  useEffect(() => {
    // Focus input when component mounts
    if (inputRef.current) {
      inputRef.current.focus()
    }

    // Cleanup object URLs on unmount
    return () => {
      attachments.forEach((att) => URL.revokeObjectURL(att.url))
    }
  }, [])

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-3xl mx-auto">
      {/* Attachments preview */}
      <AnimatePresence>
        {attachments.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-2 flex flex-wrap gap-2"
          >
            {attachments.map((att, index) => (
              <div key={index} className="relative group">
                {att.file.type.startsWith("image/") ? (
                  <div className="border rounded-md overflow-hidden">
                    <img src={att.url || "/placeholder.svg"} alt={att.file.name} className="w-20 h-20 object-cover" />
                  </div>
                ) : (
                  <div className="border rounded-md p-2 bg-gray-50 w-20 h-20 flex items-center justify-center">
                    <p className="text-xs text-center truncate">{att.file.name}</p>
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => removeAttachment(index)}
                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <XIcon size={12} />
                </button>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="rounded-2xl border border-gray-300 bg-white shadow-sm overflow-hidden">
        <div className="px-4 py-3">
          <TextareaAutosize
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              inputMode === "search"
                ? "Search for something..."
                : inputMode === "voice"
                  ? "Listening..."
                  : "Ask anything"
            }
            className="w-full outline-none text-gray-700 resize-none"
            disabled={isLoading || isRecording}
            minRows={1}
            maxRows={5}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                handleSubmit(e as any)
              }
            }}
          />
        </div>

        <div className="flex items-center justify-between border-t border-gray-200 px-2 py-2">
          <div className="flex items-center gap-2">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              type="button"
              onClick={handleAttachClick}
              className={`p-2 rounded-md flex items-center gap-1 ${
                inputMode === "attach" ? "bg-gray-200 text-gray-800" : "text-gray-500 hover:bg-gray-100"
              }`}
            >
              <PaperclipIcon className="w-5 h-5" />
              <span className="text-sm">Attach</span>
            </motion.button>

            <input
              ref={fileInputRef}
              type="file"
              multiple
              onChange={handleFileChange}
              className="hidden"
              accept="image/*,application/pdf,text/plain"
            />

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              type="button"
              onClick={handleSearchClick}
              className={`p-2 rounded-md flex items-center gap-1 ${
                inputMode === "search" ? "bg-gray-200 text-gray-800" : "text-gray-500 hover:bg-gray-100"
              }`}
            >
              <SearchIcon className="w-5 h-5" />
              <span className="text-sm">Search</span>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              type="button"
              className="p-2 text-gray-500 hover:bg-gray-100 rounded-md flex items-center gap-1"
            >
              <LightbulbIcon className="w-5 h-5" />
              <span className="text-sm">Reason</span>
            </motion.button>
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            type="button"
            onClick={handleVoiceClick}
            className={`rounded-full px-3 py-1.5 flex items-center gap-1 ${
              isRecording || inputMode === "voice" ? "bg-red-500 text-white" : "bg-black text-white"
            }`}
          >
            <MicIcon className="w-4 h-4" />
            <span className="text-sm">{isRecording ? "Recording..." : "Voice"}</span>
          </motion.button>
        </div>
      </div>
    </form>
  )
}

