"use client"

import { motion } from "framer-motion"
import { PencilIcon, ChevronDownIcon } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Header() {
  return (
    <motion.header
      initial={{ y: -20 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex items-center justify-between p-4 border-b border-gray-200"
    >
      <div className="flex items-center">
        <PencilIcon className="w-5 h-5 mr-2 text-gray-600" />
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center text-gray-700 font-medium"
        >
          ChatGPT
          <ChevronDownIcon className="w-4 h-4 ml-1 text-gray-500" />
        </motion.button>
      </div>
      <div className="flex items-center gap-2">
        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button variant="outline" className="rounded-full bg-black text-white hover:bg-black/90 border-none px-4">
            Log in
          </Button>
        </motion.div>
        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button variant="outline" className="rounded-full text-black border-gray-300 hover:bg-gray-100 px-4">
            Sign up
          </Button>
        </motion.div>
      </div>
    </motion.header>
  )
}

