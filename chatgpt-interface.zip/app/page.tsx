"use client"

import { useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useChatStore } from "@/lib/store"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ChatInput from "@/components/chat-input"
import Chat from "@/components/chat"

export default function ChatGPTInterface() {
  const { isChatMode, messages, setChatMode } = useChatStore()

  // Check for existing messages in localStorage on mount
  useEffect(() => {
    if (messages.length > 0) {
      setChatMode(true)
    }
  }, [])

  return (
    <div className="flex flex-col min-h-screen bg-white">
      <Header />

      <main className="flex-1 flex flex-col">
        <AnimatePresence mode="wait">
          {isChatMode ? (
            <motion.div
              key="chat"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 flex flex-col"
            >
              <Chat />
            </motion.div>
          ) : (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="flex-1 flex flex-col items-center justify-center p-4"
            >
              <div className="max-w-2xl w-full flex flex-col items-center">
                <h1 className="text-3xl font-semibold text-gray-800 mb-8">What can I help with?</h1>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className={`p-4 ${isChatMode ? "border-t border-gray-200" : ""}`}>
          <ChatInput />
        </div>
      </main>

      <Footer />
    </div>
  )
}

