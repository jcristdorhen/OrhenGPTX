import { GoogleGenerativeAI } from "@google/generative-ai"

// Initialize the Gemini API client
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!)

export async function POST(request: Request) {
  try {
    const { messages, mode } = await request.json()

    // Get the model
    const model = genAI.getGenerativeModel({
      model: "gemini-1.5-flash",
    })

    // Convert messages to Gemini format
    const formattedHistory = messages.slice(0, -1).map((msg: any) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.content }],
    }))

    // Start a chat session
    const chat = model.startChat({
      history: formattedHistory,
      generationConfig: {
        temperature: 0.9,
        topP: 0.95,
        topK: 40,
        maxOutputTokens: 8192,
      },
    })

    // Get the last user message
    const lastMessage = messages[messages.length - 1]

    // Add system instructions for code formatting
    let userMessage = lastMessage.content
    if (mode === "search") {
      userMessage = `Search the web for: ${userMessage}`
    }

    // Add instructions for code formatting
    const systemInstructions = `
    When providing code examples, please format them with markdown code blocks using triple backticks and the language name.
    For example: \`\`\`javascript
    // Your code here
    \`\`\`
    `

    // Send the message to Gemini
    const result = await chat.sendMessage(`${systemInstructions}\n\n${userMessage}`)
    const response = await result.response
    const text = response.text()

    return new Response(JSON.stringify({ text }), {
      headers: { "Content-Type": "application/json" },
    })
  } catch (error) {
    console.error("Error calling Gemini API:", error)
    return new Response(JSON.stringify({ error: "Failed to process request" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}

